This example1.c file was the only example included with version 1.0 of the OSAL. Its main function is to show the OSAL working by passing messages between tasks. It will continue indefinitely.
