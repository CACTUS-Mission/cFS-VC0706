The OSAL black box unit tests tests were run in a ut699 SPARC Leon3/VxWorks 6.7 
environment.


The expected results of the black box unit tests in this environment are 
provide in the _log.txt file for each test.


====================================================================================
